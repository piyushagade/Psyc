1. ~~When delete item mode is on, and user clicks on save button, delete item mode should turn off.~~
2. ~~Alarm for important stuff in todo list. (not fully implemented)~~
3. Lock window in position for removing -webkit-drag-region from css (maybe use -webkit-no-drag ?).
4. Persist window positions.
5. Include weather in digital clock widget.
6. Add a search widget (google).
7. Local app launcher?